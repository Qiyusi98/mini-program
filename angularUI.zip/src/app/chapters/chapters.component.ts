import { Component, OnInit, Input } from '@angular/core';
import { Course } from '../course';
import { COURSES } from '../mock-courses';
import {CourseService} from '../course.service';
import {ActivatedRoute} from '@angular/router';
@Component({
  selector: 'app-chapters',
  templateUrl: './chapters.component.html',
  styleUrls: ['./chapters.component.css']
})
export class ChaptersComponent implements OnInit {
  @Input()
  chapters: string[];
  @Input()
  course: Course;
  constructor(private courseService: CourseService,
              private route: ActivatedRoute) { }


  ngOnInit() {}
  // getChapters(): void {
  //   const id = +this.route.snapshot.paramMap.get('id');
  //   this.courseService.getCourse(id).subscribe(course => this.chapters = course.chapterName);
  //   console.log(id);
  //   console.log(this.chapters);
  // }


}
