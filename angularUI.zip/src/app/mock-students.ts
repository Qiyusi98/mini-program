import { Student } from './student';

export const STUDENTS: Student[] = [
  {id: 1, name: 'Elizabeth'},
  {id: 2, name: 'Nancy'},
  {id: 3, name: 'Linda'}
];
