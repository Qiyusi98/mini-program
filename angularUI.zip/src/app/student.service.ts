import { Injectable } from '@angular/core';
import {Observable, of} from 'rxjs';
import { Student } from './student';
import { STUDENTS } from './mock-students';
import { COURSES } from './mock-courses';
import { Course } from './course';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }
  getStudent(id: number): Observable<Student> {
    return of(STUDENTS.find(student => student.id === id));
  }
}
