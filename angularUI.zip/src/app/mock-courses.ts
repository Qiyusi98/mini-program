import { Course } from './course';

export const COURSES: Course[] = [
  {id: 1, name: '数据库', chapterName: ['sql1', 'sql2'], students: [1, 2, 3], contents: ['1111', '222']},
  {id: 2, name: '高级web', chapterName: ['angular', 'html5'], students: [1, 2, 3], contents: ['333', '444']},
  {id: 3, name: '智商系统', chapterName: ['CNN', 'RNN'], students: [1, 2, 3], contents: ['555', '666']}
];
