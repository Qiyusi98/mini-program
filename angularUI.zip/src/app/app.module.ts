import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {MatFormFieldModule, MatProgressBarModule} from '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoursesComponent } from './courses/courses.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { StudentsComponent } from './students/students.component';
import { ChaptersComponent } from './chapters/chapters.component';
import { ChapterDetailComponent } from './chapter-detail/chapter-detail.component';
import { AddCourseComponent } from './add-course/add-course.component';
import { NavigateComponent } from './navigate/navigate.component';
import {MatProgressBarModule} from '@angular/material/progress-bar';



@NgModule({
  declarations: [
    AppComponent,
    CoursesComponent,
    CourseDetailComponent,
    StudentsComponent,
    ChaptersComponent,
    ChapterDetailComponent,
    AddCourseComponent,
    NavigateComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatProgressBarModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
