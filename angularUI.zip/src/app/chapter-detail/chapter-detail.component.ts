import { Component, OnInit } from '@angular/core';
import { CourseService} from '../course.service';
import {StudentService} from '../student.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-chapter-detail',
  templateUrl: './chapter-detail.component.html',
  styleUrls: ['./chapter-detail.component.css']
})
export class ChapterDetailComponent implements OnInit {
  contents: string[];
  studentsName: string[] = [];
  progress: number[] = [40, 50, 60];
  constructor(private courseService: CourseService,
              private studentService: StudentService,
              private location: Location) { }

  ngOnInit() {
    this.getContents();
    this.getStudents();
  }
  getContents(): void {
    this.courseService.getCourse(1)
      .subscribe(course => this.contents = course.contents);
  }
  getStudents(): void {
    let studentsId: number[];
    this.courseService.getCourse(1)
      .subscribe(course => studentsId = course.students);
    for ( const studentId of studentsId ) {
      this.studentService.getStudent(studentId)
        .subscribe(student => this.studentsName.push(student.name));
    }
  }
  goBack(): void {
    this.location.back();
  }

}
