import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Course } from './course';
import { COURSES } from './mock-courses';

@Injectable({
  providedIn: 'root'
})
export class CourseService {

  constructor(
    ) {}
  getCourses(): Observable<Course[]> {
    return of(COURSES);
  }
  getCourse(id: number): Observable<Course> {
    return of(COURSES.find(course => course.id === id));
  }
  addCourse(courseName: string, chapterName: string, contents: string): void {
    const length = COURSES.length;
    COURSES.push(new Course(length + 1, courseName, chapterName, contents));
  }
}
