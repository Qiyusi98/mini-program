import { Component, OnInit } from '@angular/core';
import { Student } from '../student';
import { CourseService } from '../course.service';
import {ActivatedRoute, NavigationEnd, Router} from '@angular/router';
import {Course} from '../course';
import {StudentService} from '../student.service';

@Component({
  selector: 'app-course-detail',
  templateUrl: './course-detail.component.html',
  styleUrls: ['./course-detail.component.css']
})
export class CourseDetailComponent implements OnInit {
  studentsName: string[] = [];
  chapters: string[];
  course: Course;
  constructor(private courseService: CourseService,
              private studentService: StudentService,
              private route: ActivatedRoute,
              private router: Router) {
    this.router.events.subscribe((event: any) => {
      if (event instanceof NavigationEnd) {
        console.log(event);
        this.getCourses();
      }
    });
  }

  ngOnInit() {
    this.getCourses();
  }
  getCourses(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    console.log(id);
    // this.courseService.getCourse(id)
    //   .subscribe(course => this.studentsId = course.students);
    this.courseService.getCourse(id)
      .subscribe(course => this.chapters = course.chapterName);
    this.courseService.getCourse(id)
      .subscribe(course => this.course = course);
    let studentsId: number[];
    this.courseService.getCourse(1)
      .subscribe(course => studentsId = course.students);
    this.studentsName = [];
    for ( const studentId of studentsId ) {
      this.studentService.getStudent(studentId)
        .subscribe(student => this.studentsName.push(student.name));
    }
  }

}
