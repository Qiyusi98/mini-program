import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CoursesComponent } from './courses/courses.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { ChaptersComponent } from './chapters/chapters.component';
import { StudentsComponent } from './students/students.component';
import { AddCourseComponent} from './add-course/add-course.component';
import {ChapterDetailComponent } from './chapter-detail/chapter-detail.component';


const routes: Routes = [
  { path: 'course_detail/:id', component: CourseDetailComponent},
  { path: 'students', component: StudentsComponent, },
  { path: 'chapters', component: ChaptersComponent,  },
  { path: 'add_course', component: AddCourseComponent },
  { path: 'chapter_detail/:id', component: ChapterDetailComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
