export class Course {
  id: number;
  name: string;
  chapterName: string[] = [];
  students: number[] = [];
  contents: string[];
  constructor(id, name, chapterName, contents) {
    this.id = id;
    this.name = name;
    this.chapterName.push(chapterName);
    this.contents = contents;
  }
}
