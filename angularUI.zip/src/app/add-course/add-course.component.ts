import { Component, OnInit, Input } from '@angular/core';
import { Course } from '../course';
import { CourseService } from '../course.service';
import {MatFormFieldModule} from '@angular/material';
import { Location} from '@angular/common';

@Component({
  selector: 'app-add-course',
  templateUrl: './add-course.component.html',
  styleUrls: ['./add-course.component.css']
})
export class AddCourseComponent implements OnInit  {
  courses: Course[];
  constructor(private courseService: CourseService,
              private location: Location) { }

  ngOnInit() {

  }
  getCourses(): void {
    this.courseService.getCourses().subscribe(courses => this.courses = courses);
  }
  add(courseName: string, chapterName: string, teachingContents: string): void {
    this.courseService.addCourse(courseName, chapterName, teachingContents);
  }
  goback(): void {
    this.location.back();
  }

}
